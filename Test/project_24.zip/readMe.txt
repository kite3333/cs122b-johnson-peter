Group 24 (Johnson Rey Liu and Peter Huynh)
Project 1 for CS 122B, Spring 2012

HOW TO CREATE AND RUN PROJECT
1. Log into mysql as the root user.
2. Run createTable_24.sql.
3. Run data.sql.
4. Compile and run MainMenu.java.