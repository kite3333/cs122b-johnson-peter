/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package usermanagementinterface;

import java.sql.*;				// Enable SQL processing
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;

/**
 *
 * @author johnsonliu
 */
public class UserManagementInterface {

    /**
     * @param args the command line arguments
     */
public static ArrayList userList = new ArrayList();
    
public static String grantText = "";
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        // TODO code application logic here
        
            refresh();
        
    }
    
    public static String getGrantText()
    {
        return grantText;
    }
    
    public static ArrayList getUserList()
    {
        return userList;
    }
    
    public static void refresh() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException
    {
        MainJFrame mainJFrame = new MainJFrame();
        populateTableAndUserTextBox(mainJFrame);
        
        mainJFrame.show();
    }
    
    public static void populateTableAndUserTextBox(MainJFrame mainJ) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException
    {
        // Incorporate mySQL driver
		Class.forName("com.mysql.jdbc.Driver").newInstance();
            
		 // Connect to MySQL as root
		Connection connection = DriverManager.getConnection("jdbc:mysql://","root", "");
		
		// Create and execute an SQL statement to get all the database names
		Statement myDBStm = connection.createStatement();
		ResultSet resultDB = myDBStm.executeQuery("show databases");
		String dbName;
		while (resultDB.next())
		{
			dbName = resultDB.getString(1);
			//only get information inside the "moviedb" database
			if (dbName.compareTo("moviedb")==0)
			{
				//first, we need to switch to this database;
				Statement mySWStm = connection.createStatement();
				mySWStm.execute("use moviedb");
				//Create and execute an SQL statement to get all the table names in moviedb
				Statement myTBStm = connection.createStatement();
				ResultSet resultTB = myTBStm.executeQuery("show tables");
				//myStm.close();			
				String tblName;
				ResultSet ColData;
				Statement myColStm;
				while (resultTB.next())
				{
					tblName = resultTB.getString(1);
					//mainJ.addToTextBox("\n**Table Name:** " + tblName + "\n");
                                        
                                        
                                        System.out.println("\n**Table Name:** " + tblName + "\n");
					System.out.println("Metadata about columns in this table:\n");
					System.out.println("==== Field Name ==== Field Type ===== Null Allowed ?");
					System.out.println("----------------------------------------------------");
					myColStm = connection.createStatement();
					// Create and execute an SQL statement to get all the column names for this table
					ColData = myColStm.executeQuery("describe "+tblName);
					//myStm.close();
					while (ColData.next())
					{
						System.out.print("==== "+ColData.getString(1));
						System.out.print("==== "+ColData.getString(2));
						System.out.println("==== "+ColData.getString(3));
					}					
				}
                                
                                Statement userStatement = connection.createStatement();
				ResultSet userResult = userStatement.executeQuery("select user, host from mysql.user;");
                                
                
                                
                                int i = 0;
//                                Vector<String> temp = new Vector<String>();
                                
                                while(userResult.next())
                                {
                                    
                                    i++;
                                    String firstUser = userResult.getString(1);
                                    userList.add(firstUser);
                                    String host = userResult.getString(2);
                                    
                                    String user = firstUser + "        " + host + '\n';
                                    
                                Statement grantsStatement = connection.createStatement();
                                String query = "show grants for '" + firstUser + "'@'" + host + "';";
				ResultSet grantsResult = grantsStatement.executeQuery(query);
                                System.out.println("query is " + query);
                                    

                                    while(grantsResult.next())
                                    {
                                        String grants = grantsResult.getString(1);
                                        user += grants + '\n';
                                        grantText += grants + '\n';
                                        
                                    }
                                    
                                    user += '\n';
                                    System.out.println("we add " + user);
                                    mainJ.addToUserTextBox(user);
                                    
                                    
                                }

			}
		}
               
                
    }
}
